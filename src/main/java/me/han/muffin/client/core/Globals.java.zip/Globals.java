package me.han.muffin.client.core;

import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.client.FMLClientHandler;

public class Globals {
    public static final Minecraft mc = Minecraft.getMinecraft();
    public static final FMLClientHandler clientHandler = FMLClientHandler.instance();
}